// commands/calculator.js
module.exports = {
    data: {
        name: 'cal',
        description: 'Realiza operaciones básicas: suma, resta, multiplicación y división.',
        options: [
            {
                name: 'operation',
                type: 'STRING',
                description: 'La operación a realizar: add, subtract, multiply, divide',
                required: true,
            },
            {
                name: 'number1',
                type: 'NUMBER',
                description: 'Primer número',
                required: true,
            },
            {
                name: 'number2',
                type: 'NUMBER',
                description: 'Segundo número',
                required: true,
            },
        ],
    },
    execute(message, args) {
        const number1 = parseFloat(args[0]);
        const operation = args[1];
        const number2 = parseFloat(args[2]);
        let result;

        switch (operation) {
            case '+':
                result = (number1 + number2).toFixed(3);
                break;
            case '-':
                result = (number1 - number2).toFixed(3);
                break;
            case '*':
                result = (number1 * number2).toFixed(3);
                break;
            case '/':
                if (number2 === 0) {
                    message.channel.send('¡No se puede dividir entre cero!');
                    return;
                }
                result = (number1 / number2).toFixed(3);
                break;
            default:
                message.channel.send('Operación no válida.');
                return;
        }

        result = Number(result);

        // Formatea el resultado
        const formattedResult = Number.isInteger(result) ? result.toFixed(0) : result.toFixed(3);
        message.reply(`${number1} ${operation} ${number2} = ${formattedResult}`);
    },
};
