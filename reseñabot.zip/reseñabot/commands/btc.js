module.exports = {
  data: {
    name: 'btc'
    },
    execute(message) {
        const response = '### <:BTC:1174221711235887114> **Bitcoin** <:BTC:1174221711235887114> \n > **```1LpXLdA1GqFqzH1nJ6bTvehRW7KxgGQ2uy```**';
        message.channel.send(response);
        message.delete()
    },
};
