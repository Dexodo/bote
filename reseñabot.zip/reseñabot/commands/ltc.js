module.exports = {
  data: {
    name: 'ltc'
    },
    execute(message) {
        const response = '### <:LTC:1171553143075635200> **Litecoin** <:LTC:1171553143075635200> \n > **```LXFvvozrpy9bJ62qyztmpocJ8EJ4SbBeqQ```**';
        message.channel.send(response);
        message.delete()
    },
};
