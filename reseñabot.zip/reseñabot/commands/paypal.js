const { EmbedBuilder } = require('discord.js');

module.exports = {
  data: {
    name: 'paypal'
    },
    execute(message) {
        // Crea el embed
        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setDescription('## <:Paypal:1174221719729348668> **__PayPal__** <:Paypal:1174221719729348668> \n\n ### ● Email ```andressaud18@gmail.com```\n\n ### ● Username ```@soulggv2```\n### ● Fees ```4.5% + 0.3$```')
            .setFooter({text: 'Proporciona El Comprobante Del Pago', iconURL: 'https://cdn.discordapp.com/emojis/1235320060801974303.gif?size=80&quality=lossless'})
            .setTimestamp();

        // Envía el embed al canal
        message.channel.send({ embeds: [embed] });
        message.delete()
        }
    };

