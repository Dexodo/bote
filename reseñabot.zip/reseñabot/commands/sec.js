module.exports = {
  data: {
    name: 'sec'
    },
    execute(message) {
        const response = '* <a:wait:1263351340147544094> **[ Estamos atendiendo su orden ]**\n* <a:wait:1263351340147544094> **[ Espere pacientemente ]**';
        message.channel.send(response);
    },
};
