const { EmbedBuilder } = require('discord.js');

module.exports = {
  data: {
    name: 'bs'
    },
    execute(message) {
        // Crea el embed
        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setDescription('## <:pagomovil:1211151190146949141> **__Pago Movil__** <:pagomovil:1211151190146949141> \n\n ### ● Cedula De Identidad ```30593649``` \n ### ● Numero De Telefono ```04249092068``` \n ### ● Banco ```0102 Vzla```')
            .setFooter({text: 'Proporciona El Comprobante Del Pago', iconURL: 'https://cdn.discordapp.com/emojis/1235320060801974303.gif?size=80&quality=lossless'})
            .setTimestamp();

        // Envía el embed al canal
        message.channel.send({ embeds: [embed] });
        message.delete()
        }
    };

