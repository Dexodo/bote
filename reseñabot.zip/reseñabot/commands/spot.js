const { EmbedBuilder } = require('discord.js');

module.exports = {
  data: {
    name: 'spot'
    },
    execute(message) {
        // Crea el embed
        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('<:gp:1212085413859303466> Spot Trade <:gp:1212085413859303466>')
            .setDescription('* <:lumb:1263213101025595452> **[ City - Lumb ]**\n* <:Chest:1263213995276370043> **[ Spot - B. Chest ]**\n* <:tut:1216511861965455470> **[ Name - GG ReWin ]**\n* <:w308:1263212208268247175> **[ World - 308 ]**')
            .setThumbnail('https://media.discordapp.net/attachments/1203913593221947472/1263346955778654299/image.png?ex=6699e70a&is=6698958a&hm=7a310453d957b0328c31de20548bb03180452c4710d43f8ac06415c32e0610c7&=&format=webp&quality=lossless')
            .setImage('https://cdn.discordapp.com/attachments/1215881902993440860/1291110002655756288/image.png?ex=670d67e4&is=670c1664&hm=bcc6ea2b49aba2010c1d3d062d6513508c0b4e230793496803f1f0463ad51889&') // Reemplaza con la URL de tu imagen
            .setTimestamp()
            .setFooter({text: 'Trade safe with GG', iconURL: 'https://cdn.discordapp.com/emojis/1063946743256993922.gif?size=96&quality=lossless'});

        // Envía el embed al canal
        message.channel.send({ embeds: [embed] });
        message.delete()
        }
    };


