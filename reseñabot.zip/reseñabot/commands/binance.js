const { EmbedBuilder } = require('discord.js');

module.exports = {
  data: {
    name: 'binance'
    },
    execute(message) {
        // Crea el embed
        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setDescription('## <:binance:1200632931220193280> **__Binance__** <:binance:1200632931220193280> \n \n ### ● Pay ID ```747963590``` \n ### ● User ID ```747982028``` \n ### ● Correo ```ggstorev1@gmail.com```')
            .setFooter({text: 'Proporciona El Comprobante Del Pago', iconURL: 'https://cdn.discordapp.com/emojis/1235320060801974303.gif?size=80&quality=lossless'})
            .setTimestamp();

        // Envía el embed al canal
        message.channel.send({ embeds: [embed] });
        message.delete()
        }
    };

