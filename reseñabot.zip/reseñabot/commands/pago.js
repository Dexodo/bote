module.exports = {
  data: {
    name: 'pago'
    },
    execute(message) {
        const response = '* <:cash:1264643808361054228> **[ Envíanos tus datos de pago ]**\n* <:cash:1264643808361054228> **[ Evita colocar caracteres especiales ]**';
        message.channel.send(response);
        message.delete()
    },
};
