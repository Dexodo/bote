// commands/buttonCommand.js
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = {
  data: {
    name: 'vouch',
    description: 'Envía un mensaje con un botón que abre un modal.',
    },
    execute(message) {
      const button = new ButtonBuilder()
        .setCustomId('open_modal')
        .setLabel('Deja Tu Referencia')
        .setEmoji('<:puntaje:1218408470353674280>')
        .setStyle(ButtonStyle.Success);

      const row = new ActionRowBuilder().addComponents(button);

      message.channel.send({
        content: '**<:pepeamor:1212082806159835231> ¿ Podrias dejarnos una referencia ? <:pepeamor:1212082806159835231> **\n\n* **Esto no toma mas de 1 minuto**\n* **Dale al boton y rellena los campos**',
        components: [row],
      });
      message.delete()
    },
};

