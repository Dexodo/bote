const { Client, GatewayIntentBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');
const dotenv = require('dotenv');
const fs = require('fs');
const path = require('path');

dotenv.config();

const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]
});

let contadorReseñas = 0;

// Función para leer el contador de reseñas desde el archivo
function leerContador() {
  try {
    const data = fs.readFileSync('contador.txt', 'utf8');
    contadorReseñas = parseInt(data.trim());
    console.log("Contador de reseñas cargado:", contadorReseñas);
  } catch (err) {
    console.error("Error al leer el archivo del contador:", err);
  }
}

// Función para guardar el contador de reseñas en el archivo
function guardarContador() {
  fs.writeFile('contador.txt', contadorReseñas.toString(), (err) => {
    if (err) {
      console.error("Error al guardar el contador:", err);
    } else {
      console.log("Contador de reseñas guardado:", contadorReseñas);
    }
  });
}

// Llamar a la función para cargar el contador al iniciar el bot
leerContador();

// Cargar comandos
client.commands = new Map();

const commandFiles = fs.readdirSync(path.join(__dirname, 'commands')).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const command = require(`./commands/${file}`);
    client.commands.set(command.data.name, command);
}

client.once('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});

// Manejo de errores no manejados
process.on('uncaughtException', (error) => {
    fs.appendFileSync('error_log.txt', `${new Date().toISOString()} - Uncaught Exception: ${error.message}\n${error.stack}\n`);
});

process.on('unhandledRejection', (reason, promise) => {
    fs.appendFileSync('error_log.txt', `${new Date().toISOString()} - Unhandled Rejection at: ${promise}, reason: ${reason}\n`);
});


client.on('messageCreate', async message => {
    if (!message.content.startsWith('!') || message.author.bot) return;

    const args = message.content.slice(1).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    const command = client.commands.get(commandName);

    

if (command) {
    command.execute(message, args).catch(error => {
        fs.appendFileSync('error_log.txt', `${new Date().toISOString()} - Command Execution Error: ${error.message}\n${error.stack}\n`);
    });
} else {
    console.log(`Comando no encontrado: ${commandName}`);
}

});



client.on('interactionCreate', async interaction => {
    try {
        if (interaction.isButton()) {
            if (interaction.customId === 'open_modal') {
                const modal = new ModalBuilder()
                    .setCustomId('modal_input')
                    .setTitle('Entrada del Usuario');

                const textInput = new TextInputBuilder()
                    .setCustomId('text_input')
                    .setLabel('Escribe tu texto:')
                    .setStyle(TextInputStyle.Short);

                const numberInput = new TextInputBuilder()
                    .setCustomId('number_input')
                    .setLabel('Elige un número del 1 al 5:')
                    .setStyle(TextInputStyle.Short);

                const reseñas = new ActionRowBuilder().addComponents(textInput);
                const numEstrellas = new ActionRowBuilder().addComponents(numberInput);

                modal.addComponents(reseñas, numEstrellas);
                await interaction.showModal(modal);
            }
        }

if (interaction.isModalSubmit()) {
    if (interaction.customId === 'modal_input') {
        const text = interaction.fields.getTextInputValue('text_input');
        const number = interaction.fields.getTextInputValue('number_input');
        const avatarURL = interaction.user.displayAvatarURL({ format: "png", dynamic: true });
        const username = interaction.user.username;
        const estrellasEmoji = '<:puntaje:1218408470353674280>'.repeat(number);
        
contadorReseñas++;
guardarContador();
   
const embed = new EmbedBuilder()
    .setAuthor({
        name: `Referencia #${contadorReseñas}`,
        iconURL: avatarURL
    })
    .setTitle(`Referencia de ${username}`)
    .setDescription(`# ${text}`)
    .addFields([
        { name: "**PUNTAJE:**", value: `${estrellasEmoji} [${number}/5]` }
    ])
    .setColor("#e3aafd")
    .setFooter({
        text: "Gracias por elegir a GG"
    })
    .setTimestamp();

const button = new ButtonBuilder()
        .setCustomId('open_modal')
        .setLabel('Deja Tu Referencia')
        .setEmoji('<:puntaje:1218408470353674280>')
        .setStyle(ButtonStyle.Success);

        const row = new ActionRowBuilder().addComponents(button);

        const channelId = client.channels.cache.get(process.env.CHANNEL_ID);
        if (channelId) {
          await channelId.send({ embeds: [embed], components: [row] });
          await interaction.reply({ content: 'Referencia enviada.', ephemeral: true });
          
        } else {
          await interaction.reply({ content: 'No se pudo encontrar el canal.' });
        }
      
    }
}
    } catch (error) {
        fs.appendFileSync('error_log.txt', `${new Date().toISOString()} - Interaction Error: ${error.message}\n${error.stack}\n`);
        await interaction.reply({ content: 'Hubo un error procesando tu solicitud.' });
    }
});


client.login(process.env.DISCORD_TOKEN);
